This folder contains the BMP versions of all the Touchscreen display background images in release 61F_220622_v1.
Neither these files nor this folder are needed, for flashing the firmware to your display.

I have included them here only to facilitate the efforts of anyone wanting to raise issues or to propose changes to this UI.

NOTE that the Icons and Toggle buttons are NOT included in these bitmaps. Those are separate overlays invoked at run-time.